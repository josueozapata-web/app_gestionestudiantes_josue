// Exceptions/EstudianteExceptions.cs
namespace GestionEstudiantes.Exceptions
{
    public class ValidationException : Exception
    {
        public ValidationException(string message) : base($"Error de validación: {message}") { }
    }

    public class BusinessException : Exception
    {
        public BusinessException(string message) : base(message) { }
    }

    public class NotFoundException : Exception
    {
        public NotFoundException(string message) : base(message) { }
    }

    public class InfrastructureException : Exception
    {
        public InfrastructureException(string message, Exception innerException)
            : base(message, innerException) { }
    }
}
