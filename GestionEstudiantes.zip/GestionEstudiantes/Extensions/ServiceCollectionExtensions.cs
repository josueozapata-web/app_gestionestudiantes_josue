// Extensions/ServiceCollectionExtensions.cs
using GestionEstudiantes.Infrastructure;
using GestionEstudiantes.Models;
using GestionEstudiantes.Repositories;
using GestionEstudiantes.Services;
using GestionEstudiantes.Validators;

namespace GestionEstudiantes.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddEstudiantesModule(this IServiceCollection services)
        {
            services.AddScoped(typeof(JsonFileService<>));
            services.AddScoped<IEstudianteRepository, EstudianteRepository>();
            services.AddScoped<EstudianteService>();
            services.AddScoped<IValidator<Estudiante>, EstudianteValidator>();
            return services;
        }
    }
}
