// Infrastructure/JsonFileService.cs
using System.Text.Json;
using GestionEstudiantes.Exceptions;

namespace GestionEstudiantes.Infrastructure
{
    public class JsonFileService<T> where T : class
    {
        private readonly JsonSerializerOptions _options;

        public JsonFileService()
        {
            _options = new JsonSerializerOptions
            {
                WriteIndented = true,
                PropertyNameCaseInsensitive = true
            };
        }

        public List<T> LoadFromFile(string filePath)
        {
            try
            {
                if (!File.Exists(filePath))
                    return new List<T>();

                var json = File.ReadAllText(filePath);

                if (string.IsNullOrWhiteSpace(json))
                    return new List<T>();

                return JsonSerializer.Deserialize<List<T>>(json, _options) ?? new List<T>();
            }
            catch (JsonException ex)
            {
                throw new InfrastructureException($"Error al deserializar {filePath}", ex);
            }
        }

        public void SaveToFile(List<T> data, string filePath)
        {
            try
            {
                var directory = Path.GetDirectoryName(filePath);
                if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
                    Directory.CreateDirectory(directory);

                var json = JsonSerializer.Serialize(data, _options);
                File.WriteAllText(filePath, json);
            }
            catch (JsonException ex)
            {
                throw new InfrastructureException("Error al serializar datos", ex);
            }
        }
    }
}
