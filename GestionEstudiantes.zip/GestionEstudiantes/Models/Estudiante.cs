// Models/Estudiante.cs
namespace GestionEstudiantes.Models
{
    public class Estudiante
    {
        public int Id { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public int Edad { get; set; }
        public double Promedio { get; set; }

        public bool EstaAprobado() => Promedio >= 6;

        public string ObtenerCategoria()
        {
            if (Promedio >= 9) return "Excelente";
            if (Promedio >= 7) return "Bueno";
            if (Promedio >= 6) return "Suficiente";
            return "Insuficiente";
        }

        public bool EsMenorDeEdad() => Edad < 18;

        public string PromedioFormateado() => Promedio.ToString("F2");

        public override string ToString() =>
            $"{Nombre} - {PromedioFormateado()} ({ObtenerCategoria()})";
    }
}
