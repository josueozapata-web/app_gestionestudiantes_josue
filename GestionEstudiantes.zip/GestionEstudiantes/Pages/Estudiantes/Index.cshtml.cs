// Pages/Estudiantes/Index.cshtml.cs
using GestionEstudiantes.Exceptions;
using GestionEstudiantes.Models;
using GestionEstudiantes.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GestionEstudiantes.Pages.Estudiantes
{
    public class IndexModel : PageModel
    {
        private readonly EstudianteService _service;
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(EstudianteService service, ILogger<IndexModel> logger)
        {
            _service = service;
            _logger = logger;
        }

        // ── Datos de la página ─────────────────────────────────────
        public List<Estudiante> Estudiantes { get; set; } = new();
        public EstadisticasEstudiantes? Estadisticas { get; set; }
        public string? MensajeExito { get; set; }
        public string? MensajeError { get; set; }

        // ── Formulario agregar ─────────────────────────────────────
        [BindProperty]
        public Estudiante NuevoEstudiante { get; set; } = new();

        // ── Formulario editar ──────────────────────────────────────
        [BindProperty]
        public Estudiante EstudianteEditar { get; set; } = new();

        // ── Filtros ────────────────────────────────────────────────
        [BindProperty(SupportsGet = true)]
        public string? FiltroNombre { get; set; }

        [BindProperty(SupportsGet = true)]
        public int? FiltroEdadMin { get; set; }

        [BindProperty(SupportsGet = true)]
        public int? FiltroEdadMax { get; set; }

        [BindProperty(SupportsGet = true)]
        public double? FiltroPromedioMin { get; set; }

        [BindProperty(SupportsGet = true)]
        public double? FiltroPromedioMax { get; set; }

        [BindProperty(SupportsGet = true)]
        public string? FiltroCategoria { get; set; }

        [BindProperty(SupportsGet = true)]
        public string? FiltroEstado { get; set; }   // "aprobado" | "reprobado" | ""

        [BindProperty(SupportsGet = true)]
        public string FiltroOrden { get; set; } = "id";

        public bool HayFiltros { get; set; }

        // ── GET ────────────────────────────────────────────────────
        public async Task OnGetAsync()
        {
            await CargarDatosAsync();
        }

        // ── POST: Agregar ──────────────────────────────────────────
        public async Task<IActionResult> OnPostAsync()
        {
            try
            {
                var nuevo = await _service.AgregarAsync(NuevoEstudiante);
                MensajeExito = $"✅ Estudiante '{nuevo.Nombre}' agregado correctamente (ID: {nuevo.Id})";
                NuevoEstudiante = new Estudiante();
            }
            catch (ValidationException ex)
            {
                MensajeError = ex.Message;
                _logger.LogWarning(ex, "Validación al agregar");
            }
            catch (BusinessException ex)
            {
                MensajeError = ex.Message;
                _logger.LogWarning(ex, "Regla de negocio al agregar");
            }
            catch (Exception ex)
            {
                MensajeError = "Ocurrió un error inesperado al agregar";
                _logger.LogError(ex, "Error al agregar estudiante");
            }

            await CargarDatosAsync();
            return Page();
        }

        // ── POST: Editar ───────────────────────────────────────────
        public async Task<IActionResult> OnPostEditarAsync()
        {
            try
            {
                var editado = await _service.EditarAsync(EstudianteEditar);
                MensajeExito = $"✅ Estudiante '{editado.Nombre}' actualizado correctamente";
            }
            catch (ValidationException ex)
            {
                MensajeError = ex.Message;
                _logger.LogWarning(ex, "Validación al editar");
            }
            catch (BusinessException ex)
            {
                MensajeError = ex.Message;
                _logger.LogWarning(ex, "Regla de negocio al editar");
            }
            catch (NotFoundException ex)
            {
                MensajeError = ex.Message;
                _logger.LogWarning(ex, "No encontrado al editar");
            }
            catch (Exception ex)
            {
                MensajeError = "Ocurrió un error inesperado al editar";
                _logger.LogError(ex, "Error al editar estudiante");
            }

            await CargarDatosAsync();
            return Page();
        }

        // ── POST: Eliminar ─────────────────────────────────────────
        public async Task<IActionResult> OnPostDeleteAsync(int id)
        {
            try
            {
                await _service.EliminarAsync(id);
                MensajeExito = "✅ Estudiante eliminado correctamente";
            }
            catch (NotFoundException ex)
            {
                MensajeError = ex.Message;
            }
            catch (Exception ex)
            {
                MensajeError = "Error al eliminar el estudiante";
                _logger.LogError(ex, "Error al eliminar estudiante {Id}", id);
            }

            await CargarDatosAsync();
            return Page();
        }

        // ── POST: Filtrar ──────────────────────────────────────────
        public async Task<IActionResult> OnPostFiltrarAsync()
        {
            await CargarDatosAsync();
            return Page();
        }

        // ── POST: Limpiar filtros ──────────────────────────────────
        public async Task<IActionResult> OnPostLimpiarAsync()
        {
            FiltroNombre      = null;
            FiltroEdadMin     = null;
            FiltroEdadMax     = null;
            FiltroPromedioMin = null;
            FiltroPromedioMax = null;
            FiltroCategoria   = null;
            FiltroEstado      = null;
            FiltroOrden       = "id";

            await CargarDatosAsync();
            return Page();
        }

        // ── Carga datos con filtros activos ────────────────────────
        private async Task CargarDatosAsync()
        {
            try
            {
                var filtros = new FiltrosEstudiante
                {
                    Nombre        = FiltroNombre,
                    EdadMin       = FiltroEdadMin,
                    EdadMax       = FiltroEdadMax,
                    PromedioMin   = FiltroPromedioMin,
                    PromedioMax   = FiltroPromedioMax,
                    Categoria     = FiltroCategoria,
                    SoloAprobados   = FiltroEstado == "aprobado"  ? true : (bool?)null,
                    SoloReprobados  = FiltroEstado == "reprobado" ? true : (bool?)null,
                    OrdenarPor    = FiltroOrden ?? "id"
                };

                HayFiltros  = filtros.HayFiltrosActivos;
                Estudiantes = await _service.FiltrarAsync(filtros);
                Estadisticas = await _service.ObtenerEstadisticasAsync();
            }
            catch (Exception ex)
            {
                MensajeError = "Error al cargar los datos";
                _logger.LogError(ex, "Error al cargar estudiantes");
                Estudiantes = new List<Estudiante>();
            }
        }
    }
}
