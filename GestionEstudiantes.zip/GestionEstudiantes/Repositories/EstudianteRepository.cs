// Repositories/EstudianteRepository.cs
using GestionEstudiantes.Exceptions;
using GestionEstudiantes.Infrastructure;
using GestionEstudiantes.Models;

namespace GestionEstudiantes.Repositories
{
    public class EstudianteRepository : IEstudianteRepository
    {
        private readonly JsonFileService<Estudiante> _jsonService;
        private readonly string _filePath;
        private readonly object _lockObject = new();

        public EstudianteRepository(IWebHostEnvironment env, JsonFileService<Estudiante> jsonService)
        {
            _jsonService = jsonService;
            _filePath = Path.Combine(env.ContentRootPath, "Data", "estudiantes.json");
        }

        public async Task<List<Estudiante>> GetAllAsync()
        {
            return await Task.Run(() => _jsonService.LoadFromFile(_filePath));
        }

        public async Task<Estudiante?> GetByIdAsync(int id)
        {
            var estudiantes = await GetAllAsync();
            return estudiantes.FirstOrDefault(e => e.Id == id);
        }

        public async Task AddAsync(Estudiante estudiante)
        {
            if (estudiante == null)
                throw new ArgumentNullException(nameof(estudiante));

            lock (_lockObject)
            {
                var estudiantes = _jsonService.LoadFromFile(_filePath);
                estudiante.Id = estudiantes.Any() ? estudiantes.Max(e => e.Id) + 1 : 1;
                estudiantes.Add(estudiante);
                _jsonService.SaveToFile(estudiantes, _filePath);
            }

            await Task.CompletedTask;
        }

        public async Task UpdateAsync(Estudiante estudiante)
        {
            if (estudiante == null)
                throw new ArgumentNullException(nameof(estudiante));

            lock (_lockObject)
            {
                var estudiantes = _jsonService.LoadFromFile(_filePath);
                var index = estudiantes.FindIndex(e => e.Id == estudiante.Id);

                if (index == -1)
                    throw new NotFoundException($"No se encontró estudiante con ID {estudiante.Id}");

                estudiantes[index] = estudiante;
                _jsonService.SaveToFile(estudiantes, _filePath);
            }

            await Task.CompletedTask;
        }

        public async Task DeleteAsync(int id)
        {
            lock (_lockObject)
            {
                var estudiantes = _jsonService.LoadFromFile(_filePath);
                var estudiante = estudiantes.FirstOrDefault(e => e.Id == id);

                if (estudiante == null)
                    throw new NotFoundException($"No se encontró estudiante con ID {id}");

                estudiantes.Remove(estudiante);
                _jsonService.SaveToFile(estudiantes, _filePath);
            }

            await Task.CompletedTask;
        }

        public async Task<bool> ExistsAsync(int id)
        {
            var estudiantes = await GetAllAsync();
            return estudiantes.Any(e => e.Id == id);
        }

        public async Task<int> CountAsync()
        {
            var estudiantes = await GetAllAsync();
            return estudiantes.Count;
        }
    }
}
