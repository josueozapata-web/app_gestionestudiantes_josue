// Services/EstudianteService.cs
using GestionEstudiantes.Exceptions;
using GestionEstudiantes.Models;
using GestionEstudiantes.Repositories;
using GestionEstudiantes.Validators;

namespace GestionEstudiantes.Services
{
    public class EstudianteService
    {
        private readonly IEstudianteRepository _repository;
        private readonly IValidator<Estudiante> _validator;

        public EstudianteService(IEstudianteRepository repository, IValidator<Estudiante> validator)
        {
            _repository = repository;
            _validator = validator;
        }

        // ── Obtener todos ──────────────────────────────────────────
        public async Task<List<Estudiante>> ObtenerTodosAsync()
        {
            return await _repository.GetAllAsync();
        }

        public async Task<Estudiante?> ObtenerPorIdAsync(int id)
        {
            if (id <= 0)
                throw new ArgumentException("El ID debe ser mayor a 0");
            return await _repository.GetByIdAsync(id);
        }

        // ── Agregar ────────────────────────────────────────────────
        public async Task<Estudiante> AgregarAsync(Estudiante nuevo)
        {
            // 1. Validar formato
            var validationResult = _validator.Validate(nuevo);
            if (!validationResult.IsValid)
                throw new ValidationException(validationResult.GetErrorsSummary());

            // 2. Regla: máximo 3 estudiantes con promedio > 9.5
            var todos = await _repository.GetAllAsync();
            if (nuevo.Promedio > 9.5 && todos.Count(e => e.Promedio > 9.5) >= 3)
                throw new BusinessException("Límite de estudiantes destacados alcanzado (máximo 3 con promedio > 9.5)");

            // 3. Regla: menores de edad necesitan promedio mínimo 6.1
            if (nuevo.Edad < 18 && nuevo.Promedio < 6.1)
                throw new BusinessException("Los estudiantes menores de edad deben tener promedio mínimo 6.1");

            await _repository.AddAsync(nuevo);
            return nuevo;
        }

        // ── Editar (NUEVO) ─────────────────────────────────────────
        public async Task<Estudiante> EditarAsync(Estudiante editado)
        {
            if (editado.Id <= 0)
                throw new ArgumentException("El ID debe ser mayor a 0");

            // 1. Validar formato
            var validationResult = _validator.Validate(editado);
            if (!validationResult.IsValid)
                throw new ValidationException(validationResult.GetErrorsSummary());

            // 2. Verificar que existe
            var existe = await _repository.GetByIdAsync(editado.Id);
            if (existe == null)
                throw new NotFoundException($"No se encontró estudiante con ID {editado.Id}");

            // 3. Regla: máximo 3 destacados (excluyendo al propio estudiante)
            var todos = await _repository.GetAllAsync();
            var destacadosSinEste = todos.Count(e => e.Promedio > 9.5 && e.Id != editado.Id);
            if (editado.Promedio > 9.5 && destacadosSinEste >= 3)
                throw new BusinessException("Límite de estudiantes destacados alcanzado (máximo 3 con promedio > 9.5)");

            // 4. Regla: menores de edad
            if (editado.Edad < 18 && editado.Promedio < 6.1)
                throw new BusinessException("Los estudiantes menores de edad deben tener promedio mínimo 6.1");

            await _repository.UpdateAsync(editado);
            return editado;
        }

        // ── Eliminar ───────────────────────────────────────────────
        public async Task EliminarAsync(int id)
        {
            if (id <= 0)
                throw new ArgumentException("El ID debe ser mayor a 0");
            await _repository.DeleteAsync(id);
        }

        // ── Filtros (NUEVO) ────────────────────────────────────────
        // Filtra por nombre, rango de edad, promedio mínimo y/o categoría
        public async Task<List<Estudiante>> FiltrarAsync(FiltrosEstudiante filtros)
        {
            var estudiantes = await _repository.GetAllAsync();
            var query = estudiantes.AsQueryable();

            if (!string.IsNullOrWhiteSpace(filtros.Nombre))
                query = query.Where(e =>
                    e.Nombre.Contains(filtros.Nombre, StringComparison.OrdinalIgnoreCase));

            if (filtros.EdadMin.HasValue)
                query = query.Where(e => e.Edad >= filtros.EdadMin.Value);

            if (filtros.EdadMax.HasValue)
                query = query.Where(e => e.Edad <= filtros.EdadMax.Value);

            if (filtros.PromedioMin.HasValue)
                query = query.Where(e => e.Promedio >= filtros.PromedioMin.Value);

            if (filtros.PromedioMax.HasValue)
                query = query.Where(e => e.Promedio <= filtros.PromedioMax.Value);

            if (!string.IsNullOrWhiteSpace(filtros.Categoria))
                query = query.Where(e => e.ObtenerCategoria() == filtros.Categoria);

            if (filtros.SoloAprobados == true)
                query = query.Where(e => e.EstaAprobado());

            if (filtros.SoloReprobados == true)
                query = query.Where(e => !e.EstaAprobado());

            // Ordenar
            query = filtros.OrdenarPor switch
            {
                "nombre"   => query.OrderBy(e => e.Nombre),
                "edad"     => query.OrderBy(e => e.Edad),
                "promedio" => query.OrderByDescending(e => e.Promedio),
                _          => query.OrderBy(e => e.Id)
            };

            return query.ToList();
        }

        // ── Estadísticas ───────────────────────────────────────────
        public async Task<EstadisticasEstudiantes> ObtenerEstadisticasAsync()
        {
            var estudiantes = await _repository.GetAllAsync();

            if (!estudiantes.Any())
                return new EstadisticasEstudiantes();

            return new EstadisticasEstudiantes
            {
                TotalEstudiantes = estudiantes.Count,
                PromedioGeneral  = Math.Round(estudiantes.Average(e => e.Promedio), 2),
                MejorEstudiante  = estudiantes.OrderByDescending(e => e.Promedio).First(),
                PeorEstudiante   = estudiantes.OrderBy(e => e.Promedio).First(),
                Aprobados        = estudiantes.Count(e => e.EstaAprobado()),
                Reprobados       = estudiantes.Count(e => !e.EstaAprobado())
            };
        }
    }

    // ── Clase de filtros ───────────────────────────────────────────
    public class FiltrosEstudiante
    {
        public string? Nombre       { get; set; }
        public int?    EdadMin      { get; set; }
        public int?    EdadMax      { get; set; }
        public double? PromedioMin  { get; set; }
        public double? PromedioMax  { get; set; }
        public string? Categoria    { get; set; }   // Excelente/Bueno/Suficiente/Insuficiente
        public bool?   SoloAprobados  { get; set; }
        public bool?   SoloReprobados { get; set; }
        public string  OrdenarPor   { get; set; } = "id"; // id/nombre/edad/promedio

        public bool HayFiltrosActivos =>
            !string.IsNullOrWhiteSpace(Nombre)    ||
            EdadMin.HasValue      || EdadMax.HasValue     ||
            PromedioMin.HasValue  || PromedioMax.HasValue  ||
            !string.IsNullOrWhiteSpace(Categoria) ||
            SoloAprobados == true || SoloReprobados == true;
    }

    // ── Estadísticas ───────────────────────────────────────────────
    public class EstadisticasEstudiantes
    {
        public int        TotalEstudiantes { get; set; }
        public double     PromedioGeneral  { get; set; }
        public Estudiante? MejorEstudiante { get; set; }
        public Estudiante? PeorEstudiante  { get; set; }
        public int        Aprobados        { get; set; }
        public int        Reprobados       { get; set; }
    }
}
