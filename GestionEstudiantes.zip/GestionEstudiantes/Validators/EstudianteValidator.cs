// Validators/EstudianteValidator.cs
using System.Text.RegularExpressions;
using GestionEstudiantes.Models;

namespace GestionEstudiantes.Validators
{
    public class EstudianteValidator : IValidator<Estudiante>
    {
        private static readonly Regex NombreRegex = new(
            @"^[a-zA-ZáéíóúÁÉÍÓÚàèìòùÀÈÌÒÙñÑüÜ\s]{2,50}$",
            RegexOptions.Compiled
        );

        public ValidationResult Validate(Estudiante estudiante)
        {
            var result = new ValidationResult();

            if (estudiante == null)
            {
                result.AddError("General", "El estudiante no puede ser nulo");
                return result;
            }

            if (string.IsNullOrWhiteSpace(estudiante.Nombre))
                result.AddError("Nombre", "El nombre es requerido");
            else if (!NombreRegex.IsMatch(estudiante.Nombre))
                result.AddError("Nombre", "El nombre debe tener entre 2 y 50 caracteres y solo contener letras");

            if (estudiante.Edad < 5 || estudiante.Edad > 99)
                result.AddError("Edad", "La edad debe estar entre 5 y 99 años");

            if (estudiante.Promedio < 0 || estudiante.Promedio > 10)
                result.AddError("Promedio", "El promedio debe estar entre 0 y 10");

            if (Math.Round(estudiante.Promedio, 2) != estudiante.Promedio)
                result.AddError("Promedio", "El promedio solo puede tener máximo 2 decimales");

            result.IsValid = result.Errors.Count == 0;
            return result;
        }

        public bool IsValid(Estudiante estudiante) => Validate(estudiante).IsValid;
    }
}
