// Validators/IValidator.cs
namespace GestionEstudiantes.Validators
{
    public interface IValidator<T>
    {
        ValidationResult Validate(T entity);
        bool IsValid(T entity);
    }
}
